<?php
/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use frontend\assets\AppAsset;

AppAsset::register($this);
$action = Yii::$app->controller->action->id;
$contact_details = common\models\ContactsInfo::findOne(1);
$contact_address = common\models\ContactAddress::find()->where(['status' => 1])->limit(3)->all();
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="index, follow">
        <link rel="shortcut icon" href="<?= Yii::$app->homeUrl; ?>assets/favicon/icon.png" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://www.google.com/recaptcha/api.js?onload=CaptchaCallback&render=explicit"></script>
        <?php $this->registerCsrfMetaTags() ?>
        <title><?= Html::encode($this->title) ?></title>
        <?php $this->head() ?>
        
        <!-- Start Global site tag (gtag.js) - Google Analytics --> 
        
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-138135112-1"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
        
          gtag('config', 'UA-138135112-1');
        </script>
        
        <!-- End Global site tag (gtag.js) - Google Analytics -->   
        
    </head>
    <body>
        <?php $this->beginBody() ?>
        <header id="header"><!--header-->
            <div class="container">
                <div class="logo">
                    <?= Html::a('<img src="' . Yii::$app->homeUrl . 'assets/images/logo.png?1222259157.415" alt="logo" class="img-fluid"/>', ['/site/index'], ['class' => '']) ?>
                </div>

                <div class="right-sd-header">
                    <div class="top-cont-section">
                        <ul class="social-icon">
                            <li><a class="fab fa-facebook-f" target="_blank" href="<?= $contact_details->facebook_link ?>"></a></li>
                            <li><a class="fab fa-twitter" target="_blank" href="<?= $contact_details->twitter_link ?>"></a></li>
                            <li><a class="fab fa-linkedin-in" target="_blank" href="<?= $contact_details->linkedin_link ?>"></a></li>
                            <li><a class="fab fa-instagram" target="_blank" href="<?= $contact_details->instegram_link ?>"></a></li>
                            <li><a class="fab fa-pinterest" target="_blank" href="<?= $contact_details->pinterest ?>"></a></li>
                            <li><a class="fab fa-youtube" target="_blank" href="<?= $contact_details->youtube_link ?>"></a></li>
                        </ul>
                        <div class="mail call"><a href="Tel:<?= $contact_details->phone ?>"><small class="samll">Contact Number</small><?= $contact_details->phone ?></a></div>
                        <div class="mail"><a href="mailto:<?= $contact_details->email ?>"><small class="samll">Email</small><?= $contact_details->email ?></a></div>

                        <button class="navbar-toggler menu-button" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <i class="fas fa-align-right"></i>
                        </button>
                    </div>

                    <nav class="navbar navbar-expand-lg">
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <?= Html::a('Home', ['/site/index'], ['class' => $action == 'index' ? 'nav-link active' : 'nav-link']) ?>
                                </li>
                                <li class="nav-item">
                                    <?= Html::a('About Us', ['/site/about'], ['class' => $action == 'about' ? 'nav-link active' : 'nav-link']) ?>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle <?= $action == 'products' || $action == 'product-details' ? 'active' : '' ?>" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Products
                                    </a>
                                    <div class="dropdown-menu " aria-labelledby="navbarDropdown">
                                        <div class="row">
                                            <div class="col-md-5 col-sm-6">
                                                <div class="menu-products">
                                                    <h2 class="nav-head-sub">Products</h2>
                                                    <ul>
                                                        <?php
                                                        $categories = \common\models\Category::find()->where(['status' => 1])->all();
                                                        if (!empty($categories)) {
                                                            foreach ($categories as $category_link) {
                                                                ?>
                                                                <li>
                                                                    <?= Html::a($category_link->category_name, ['/site/products', 'category' => $category_link->canonical_name], ['class' => '']) ?>
                                                                </li>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </ul>
                                                    <?= Html::a('View All Products', ['/site/products'], ['class' => 'view_all_product']) ?>
                                                </div>
                                            </div>
                                            <div class="col-md-7 col-sm-6">
                                                <div class="menu-top-brands">
                                                    <h2 class="nav-head-sub">Top Brands</h2>
                                                    <div class="row">
                                                        <?php
                                                        $brand_list = common\models\Brands::find()->where(['status' => 1])->all();
                                                        if (!empty($brand_list)) {
                                                            foreach ($brand_list as $brand_link) {
                                                                ?>
                                                                <div class="col-md-4 col-6">
                                                                    <?= Html::a('<div class="img-box"><img src="' . Yii::$app->homeUrl . 'uploads/brands/' . $brand_link->id . '/image.' . $brand_link->image . '" alt="' . $brand_link->brand_name . '" class="img-fluid"></div>', ['/site/products', 'brand' => $brand_link->canonical_name], ['class' => 'dropdown-item']) ?>
                                                                </div>
                                                                <?php
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </li>
                                <li class="nav-item">
                                    <?= Html::a('Services', ['/site/services'], ['class' => $action == 'services' ? 'nav-link active' : 'nav-link']) ?>
                                </li>
                                <li class="nav-item">
                                    <?= Html::a('News & Events', ['/site/news-and-events'], ['class' => $action == 'news-and-events' ? 'nav-link active' : 'nav-link']) ?>
                                </li>
                                <li class="nav-item">
                                    <?= Html::a('Blogs', ['/site/blog'], ['class' => $action == 'blog' ? 'nav-link active' : 'nav-link']) ?>
                                </li>
                                <li class="nav-item">
                                    <?= Html::a('Contact Us', ['/site/contact'], ['class' => $action == 'contact' ? 'nav-link active' : 'nav-link']) ?>
                                </li>

                            </ul>

                        </div>
                    </nav>
                </div>
            </div>
        </header>

        <?= $content ?>
        <footer>
            <div class="container">
                
                <div class="col-12 foot_logo">
                    <img src="<?= Yii::$app->homeUrl ?>assets/images/f-logo.png" class="img-fluid">
                </div>
                
                        <div class="f-contact">
                            <div class="row">
                                <?php
                                if(!empty($contact_address)){
                                    foreach ($contact_address as $contact_addres) {
                                        ?>
                                         <div class="col-md-4 col-sm-6 address">
                                    <div class="location"><?= $contact_addres->title ?></div>
                                    <?= $contact_addres->address ?>
                                </div>
                                        <?php
                                    }
                                }
                                ?>
                               
                               <div class="col-md-12 col-sm-6 qck_links">
                    <h3 class="f-head">Quick Links</h3>
                        <div class="f-link">
                            <ul>
                                <li>
                                    <?= Html::a('Home', ['/site/index']) ?>
                                </li>
                                <li>
                                    <?= Html::a('About us', ['/site/about']) ?>
                                </li>
                                <li>
                                    <?= Html::a('Services', ['/site/services']) ?>
                                </li>
                                <li>
                                    <?= Html::a('Products', ['/site/products']) ?>
                                </li>
                                <li>
                                    <?= Html::a('News & Events', ['/site/news-and-events']) ?>
                                </li>
                                <li>
                                    <?= Html::a('Blogs', ['/site/blog']) ?>
                                </li>
                                <li>
                                    <?= Html::a('Contact us', ['/site/contact']) ?>
                                </li>
                            </ul>
                        </div>
                    </div>
                                
                            </div> 
                        </div>
            </div>
        </footer>

        <section id="copyright">
            <div class="container">
                <div class="row">
                    <p>
                        Copyright © 2019 Astropackgulf LLC. All  Rights Reserved Powered by pentacodes
                    </p>
                                <ul class="social_icon">
                                    <li><a class="fab fa-facebook-f" target="_blank" href="<?= $contact_details->facebook_link ?>"></a></li>
                                    <li><a class="fab fa-twitter" target="_blank" href="<?= $contact_details->twitter_link ?>"></a></li>
                                    <li><a class="fab fa-linkedin-in" target="_blank" href="<?= $contact_details->linkedin_link ?>"></a></li>
                                    <li><a class="fab fa-instagram" target="_blank" href="<?= $contact_details->instegram_link ?>"></a></li>
                                    <li><a class="fab fa-pinterest" target="_blank" href="<?= $contact_details->pinterest ?>"></a></li>
                                    <li><a class="fab fa-youtube" target="_blank" href="<?= $contact_details->youtube_link ?>"></a></li>
                                </ul>
                </div>
            </div>
        </section>

        <!--------------------footer end----------------------->



        <?php $this->endBody() ?>
    </body>
</html>
<?php $this->endPage() ?>
<script type="text/javascript">


    $(document).ready(function () {

        $(".Brands-logo").slick({
            infinite: true,
            vertical: false,
            autoplay: true,
            autoplaySpeed: 2000,
            arrows: false,
            dots: false,
            pauseOnHover: true,
            slidesToShow: 4,
            slidesToScroll: 1,
            adaptiveHeight: true,
            prevArrow: '<button class="slide-prev"></button>',
            nextArrow: '<button class="slide-nxt"></button>',
            responsive: [{
                    breakpoint: 992,
                    settings: {
                        arrows: false,
                        slidesToShow: 3
                    }
                }, {
                    breakpoint: 768,
                    settings: {
                        arrows: false,
                        slidesToShow: 2
                    }
                }

            ]

        });
        $(".testimonials-slider").slick({
            infinite: true,
            vertical: false,
            autoplay: true,
            autoplaySpeed: 3000,
            arrows: false,
            dots: false,
            pauseOnHover: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            adaptiveHeight: true,
            prevArrow: '<button class="slide-prev"></button>',
            nextArrow: '<button class="slide-nxt"></button>',

        });
        $(".clients-slider").slick({
            infinite: true,
            vertical: false,
            autoplay: true,
            autoplaySpeed: 2000,
            arrows: false,
            dots: false,
            pauseOnHover: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            adaptiveHeight: true,
            prevArrow: '<button class="slide-prev"></button>',
            nextArrow: '<button class="slide-nxt"></button>',
            responsive: [{
                    breakpoint: 576,
                    settings: {
                        arrows: false,
                        slidesToShow: 2
                    }
                },
            ]

        });
        $(".Related-product").slick({
            infinite: true,
            vertical: false,
            autoplay: true,
            autoplaySpeed: 2000,
            arrows: false,
            dots: false,
            pauseOnHover: true,
            slidesToShow: 4,
            slidesToScroll: 1,
            adaptiveHeight: true,
            prevArrow: '<button class="slide-prev"></button>',
            nextArrow: '<button class="slide-nxt"></button>',
            responsive: [{
                    breakpoint: 992,
                    settings: {
                        arrows: false,
                        slidesToShow: 3
                    }
                }, {
                    breakpoint: 768,
                    settings: {
                        arrows: false,
                        slidesToShow: 2
                    }
                }

            ]

        });

    });

    if ($(window).width() >= 992) {
        window.onscroll = function () {
            myFunction();
        };
        var header = document.getElementById("header");
        var sticky = 300;

        function myFunction() {
            if (window.pageYOffset >= sticky) {
                header.classList.add("sticky");
            } else {
                header.classList.remove("sticky");
            }
        }
    }


    /***************************SLIDER_PRO**************************/
    $('#slider-pro').sliderPro();

    if ($('#slider-pro').length > 0) {
        $('#slider-pro').sliderPro({
            width: 750,
            height: 630,
            fade: true,
            arrows: true,
            buttons: false,
            fullScreen: false,
            shuffle: false,
            smallSize: 500,
            mediumSize: 768,
            largeSize: 1024,
            thumbnailArrows: false,
            autoplay: true,
            thumbnailWidth: 80,
            thumbnailHeight: 80,

            breakpoints: {
                500: {
                    thumbnailWidth: 60,
                    thumbnailHeight: 30
                }
            }
        });
    }

</script>
<script>
    $(document).ready(function () {
        $(document).on('submit', '.contact-enquiry', function (e) {
            e.preventDefault();
            var str = $(this).serialize();
            var res =$("#secondCaptcha").val();
            if (res == "" || res == undefined || res.length == 0)
            {
                e.preventDefault();
                if ($("#RecaptchaField1").next(".validation").length == 0) // only add if not added
                {
                    $("#RecaptchaField1").after("<div class='validation' style='color:#a94442;font-size: 13px;margin-bottom: 14px;'>Please verify that you are not a robot</div>");
                }
            }else{
            $.ajax({
                type: "POST",
                url: '<?= Yii::$app->homeUrl; ?>site/contact-enquiry',
                data: str,
                success: function (data)
                {
                    $('.validation').remove();
                    if (data == 1) {
                        $('.contact-enquiry').before('<div id="email-alert" style="color: #9f274e;font-weight: 600;font-size: 18px;line-height: 27px;">Thank you for contacting us. We will get back to you as soon as possible.</div>');
                    }
                    $('#name').val("");
                    $('#email').val("");
                    $('#phone').val("");
                    $('#company').val("");
                    $('#message').val("");
                    $('#email-alert').delay(5000).fadeOut('slow');
                }
            });
            }
        });
        
        $(document).on('submit', '.product-enquiry1', function (e) {
            var res = $("#secondCaptcha").val();
            if (res == "" || res == undefined || res.length == 0)
            {
                e.preventDefault();
                if ($("#RecaptchaField1").next(".validation").length == 0) // only add if not added
                {
                    $("#RecaptchaField1").after("<div class='validation' style='color:#a94442;font-size: 13px;margin-bottom: 14px;'>Please verify that you are not a robot</div>");
                }
            } else {
                $('.validation').remove();
            }
        });

        $(document).on('submit', '.product-enquiry2', function (e) {
            var res = $("#firstCaptcha").val();
            if (res == "" || res == undefined || res.length == 0)
            {
                e.preventDefault();
                if ($("#RecaptchaField2").next(".validation").length == 0) // only add if not added
                {
                    $("#RecaptchaField2").after("<div class='validation' style='color:#a94442;font-size: 13px;margin-bottom: 14px;'>Please verify that you are not a robot</div>");
                }
            } else {
                $('.validation').remove();
            }
        });
        $(document).on('submit', '.product-enquiry', function (e) {
            e.preventDefault();
            var str = $(this).serialize();
            $.ajax({
                type: "POST",
                url: '<?= Yii::$app->homeUrl; ?>site/products-enquiry',
                data: str,
                success: function (data)
                {
                    if (data == 1) {
                        $('.prod-success').before('<div id="email-alert" style="color: #28a745;font-weight: 600;">Your Poduct Enquiry Send Successfully</div>');
                    }
                    $('#name').val("");
                    $('#email').val("");
                    $('#phone').val("");
                    $('#message').val("");
                    $('#email-alert').delay(2000).fadeOut('slow');
                }
            });
        });

        $(document).on('click', '.quick-enqiry', function (e) {
            e.preventDefault();
            $("#details14").addClass("show");
            $('html, body').animate({
                scrollTop: $('#details14').offset().top - 200 //#DIV_ID is an example. Use the id of your destination on the page
            }, 'slow');
        });

       $(document).on('submit', '.brochure-enquiry', function (e) {
            e.preventDefault();
            var str = $(this).serialize();
            var res = $("#thirdCaptcha").val();
            if (res == "" || res == undefined || res.length == 0)
            {
                e.preventDefault();
                if ($("#RecaptchaField3").next(".validation").length == 0) // only add if not added
                {
                    $("#RecaptchaField3").after("<div class='validation' style='color:#a94442;font-size: 13px;margin-bottom: 14px;text-align: left;'>Please verify that you are not a robot</div>");
                }
            } else {
                $.ajax({
                    type: "POST",
                    url: '<?= Yii::$app->homeUrl; ?>site/brochure-download',
                    data: str,
                    success: function (data)
                    {
                        $('.validation').remove();
                        if (data != 0) {
                            window.open(data, '_blank');
                        }
                        $('#name').val("");
                        $('#email').val("");
                        $('#phone').val("");
                        $('#message').val("");
                        $('#videopopup').modal('toggle');
                    }
                });
            }

        });

        $(document).on('submit', '.news-letter', function (e) {
            e.preventDefault();
            var str = $(this).serialize();
            $.ajax({
                type: "POST",
                url: '<?= Yii::$app->homeUrl; ?>site/news-letter',
                data: str,
                success: function (data)
                {
                    if (data == 1) {
                        $('.news-letter').append('<div id="newsletter-alert" style="color: #28a745;font-weight: 600;padding-top: 10px;">Your Request Send Successfully</div>');
                    } else if (data == 2) {
                        $('.news-letter').append('<div id="newsletter-alert" style="color: #28a745;font-weight: 600;padding-top: 10px;">Already Send Rrequest</div>');
                    }
                    $('#subscribe-email').val("");
                    $('#newsletter-alert').delay(2000).fadeOut('slow');
                }
            });
        });
    });
</script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
    var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
    (function () {
        var s1 = document.createElement("script"), s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/5caf1991d6e05b735b420ad9/default';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>
<!--End of Tawk.to Script-->

<!-- WhatsHelp.io widget -->
<script type="text/javascript">
    (function () {
        var mob = '<?php echo $contact_details->mobile; ?>';
        var options = {
            whatsapp: mob, // WhatsApp number
            call_to_action: "Message us", // Call to action
            position: "right", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script');
        s.type = 'text/javascript';
        s.async = true;
        s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () {
            WhWidgetSendButton.init(host, proto, options);
        };
        var x = document.getElementsByTagName('script')[0];
        x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /WhatsHelp.io widget -->
<script>
    var CaptchaCallback = function () {
        var widget1;
        var widget2;
        var widget3;
        widget1 = grecaptcha.render('RecaptchaField1', {'sitekey': '6LeV3s8UAAAAAF-aBw62xSSGAQSbRPvcmrVuAAT1', 'callback': correctCaptcha_second});
        widget2 = grecaptcha.render('RecaptchaField2', {'sitekey': '6LeV3s8UAAAAAF-aBw62xSSGAQSbRPvcmrVuAAT1', 'callback': correctCaptcha_first});
        widget3 = grecaptcha.render('RecaptchaField3', {'sitekey': '6LeV3s8UAAAAAF-aBw62xSSGAQSbRPvcmrVuAAT1', 'callback': correctCaptcha_third});
    };
    var correctCaptcha_second = function (response) {
        $("#secondCaptcha").val(response);
    };
    var correctCaptcha_first = function (response) {
        $("#firstCaptcha").val(response);
    };
    var correctCaptcha_third = function (response) {
        $("#thirdCaptcha").val(response);
    };
</script>


